package inetaddressdemo;
import java.net.InetAddress;

public class InetAddressExample {
    public static void main(String[] args) throws Exception {
        InetAddress[] addresses = InetAddress.getAllByName("google.com");
        System.out.println("IP addresses for google.com:");
        for (InetAddress addr : addresses) {
            System.out.println(addr.getHostName());
            System.out.println(addr.getHostAddress());
        }
    }
}
