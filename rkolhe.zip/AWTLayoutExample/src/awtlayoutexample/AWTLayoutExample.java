/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package awtlayoutexample;
import java.awt.*;
import java.awt.event.*;

public class AWTLayoutExample extends Frame {

    // Constructor to set up the frame
    public AWTLayoutExample() {
        // Set the title of the frame
        setTitle("AWT Layout Example");

        // Set layout as BorderLayout (default)
        setLayout(new BorderLayout());

        // Create buttons for demonstration
        Button btn1 = new Button("North");
        Button btn2 = new Button("South");
        Button btn3 = new Button("East");
        Button btn4 = new Button("West");
        Button btn5 = new Button("Center");

        // Add buttons to the frame using BorderLayout
        add(btn1, BorderLayout.NORTH);
        add(btn2, BorderLayout.SOUTH);
        add(btn3, BorderLayout.EAST);
        add(btn4, BorderLayout.WEST);
        add(btn5, BorderLayout.CENTER);

        // Set frame size and visibility
        setSize(500, 400);
        setVisible(true);

        // Add window listener to handle close operation
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                dispose();
            }
        });
    }

    // Method to demonstrate FlowLayout
    public void showFlowLayout() {
        // Set the layout to FlowLayout
        setLayout(new FlowLayout());

        // Create buttons for FlowLayout
        Button btn1 = new Button("Button 1");
        Button btn2 = new Button("Button 2");
        Button btn3 = new Button("Button 3");
        Button btn4 = new Button("Button 4");

        // Add buttons to the frame
        add(btn1);
        add(btn2);
        add(btn3);
        add(btn4);

        // Set frame size and visibility
        setSize(500, 400);
        setVisible(true);
    }

    // Method to demonstrate GridBagLayout
    public void showGridBagLayout() {
        // Set the layout to GridBagLayout
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Create buttons for GridBagLayout
        Button btn1 = new Button("1");
        Button btn2 = new Button("2");
        Button btn3 = new Button("3");
        Button btn4 = new Button("4");

        // Set constraints and add buttons to the frame
        gbc.gridx = 0; gbc.gridy = 0;
        add(btn1, gbc);

        gbc.gridx = 1; gbc.gridy = 0;
        add(btn2, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(btn3, gbc);

        gbc.gridx = 1; gbc.gridy = 1;
        add(btn4, gbc);

        // Set frame size and visibility
        setSize(500, 400);
        setVisible(true);
    }

    public static void main(String[] args) {
        // Create an instance of the frame
        AWTLayoutExample layoutExample = new AWTLayoutExample();

        // Uncomment the following lines to see each layout:
        
        // Show BorderLayout (default)
        // layoutExample.setLayout(new BorderLayout());

        // Show FlowLayout
        // layoutExample.showFlowLayout();

        // Show GridBagLayout
        // layoutExample.showGridBagLayout();
    }
}
