import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        double num1 = Double.parseDouble(request.getParameter("num1"));
        double num2 = Double.parseDouble(request.getParameter("num2"));
        String operation = request.getParameter("operation");
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        double result = 0;
        String message = "";

        // Perform operation
        switch (operation) {
            case "add": result = num1 + num2; break;
            case "subtract": result = num1 - num2; break;
            case "multiply": result = num1 * num2; break;
            case "divide": result = num1 / num2; break;
            default: message = "Invalid operation!";
        }

        // Prepare response
        out.println("<html><body>");
        out.println("<h2>Calculator Result</h2>");
        
        out.println("<p>Result: " + result + "</p>");
        
        out.println("</body></html>");
    }
}
