import java.rmi.*;

public class HelloClient {
    public static void main(String[] args) throws Exception {
        Hello obj = (Hello) Naming.lookup("rmi://localhost/HelloService");
        System.out.println(obj.sayHello());
    }
}
