import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class HelloImp extends UnicastRemoteObject implements Hello {
    HelloImp() throws RemoteException {}

    public String sayHello() { return "Hello from RMI Server!"; }

    public static void main(String[] args) throws Exception {
        LocateRegistry.createRegistry(1099);
        HelloImp obj = new HelloImp();
        Naming.rebind("HelloService", obj);
        System.out.println("Server ready.");
    }
}
