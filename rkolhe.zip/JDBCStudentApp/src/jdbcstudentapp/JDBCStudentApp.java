package jdbcstudentapp;
import java.sql.*;

public class JDBCStudentApp {
    public static void main(String[] args) {
        
        // Specify connection requirements
        String url = "jdbc:mysql://localhost:3306/school";
        String user = "root";
        String pass = "pass";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, pass);
            System.out.println("Connected to the Database!");

            // Insert a student
            PreparedStatement ps = conn.prepareStatement("INSERT INTO students (name, marks) VALUES (?, ?)");
            ps.setString(1, "Alice");
            ps.setInt(2, 85);
            ps.executeUpdate();
            System.out.println("Inserted Alice!");

            // Retrieve and print students
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
            while (rs.next()) {
            // Retrieve the value for each column by specifying the column name
                int id = rs.getInt("id");          // Get the 'id' column as an integer
                String name = rs.getString("name"); // Get the 'name' column as a string
                int marks = rs.getInt("marks");    // Get the 'marks' column as an integer
    
                // Print the values in a simple and easy-to-understand format
                System.out.println(id + " | " + name + " | " + marks);
            }


            // Close all
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

//CREATE DATABASE school;
//
//USE school;
//
//CREATE TABLE students (
//    id INT PRIMARY KEY AUTO_INCREMENT,
//    name VARCHAR(50),
//    marks INT
//);
